import * as React from 'react';
import { Form, Input, Select } from 'antd';

const Option = Select.Option;

export const InputField = ({
    field, 
    form: { touched, errors }, 
    ...props
}) => {
    const errorMessage = touched[field.name] && errors[field.name];
    return (
        <Form.Item
        style={props.hidden ? {display:'none'} : {display:'block'}}
        label={props.label}
            {...props.formitemlayout}
            help={errorMessage}
            validateStatus={errorMessage ? "error" : undefined}>
            <Input
                {...field}
                {...props}
            />
        </Form.Item>
    )
};

export const SelectField = ({
    field, 
    form: { touched, errors }, 
    ...props
}) => {
    const errorMessage = touched[field.name] && errors[field.name];
    const children = [];
    props.data && props.data.map((item,i) => {
        children.push(<Option key={item.id}>{item.name}</Option>);
    });
    return (
        <Form.Item
        style={props.hidden ? {display:'none'} : {display:'block'}}
        label={props.label}
            {...props.formitemlayout}
            help={errorMessage}
            validateStatus={errorMessage ? "error" : undefined}>
            <Select
                {...field}
                {...props}
            >
            {children}
            </Select>
        </Form.Item>
    )
};