export const validLogin = "Login Başarılı";
export const invalidLogin = "Login Başarısız! Şifre ya da email adresinizi kontrol ediniz.";
export const emailValid = "Lütfen geçerli bir mail adresi giriniz";
export const passMinLength = "Şifre en az 6 karakter uzunluğunda olmalıdır";
export const requiredMes = "Bu alan zorunludur";